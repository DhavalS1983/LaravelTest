<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

class Product extends Model
{
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    use SoftDeletes;
    protected $table = 'products';
     public function getImageAttribute($value)
    {
        return env('APP_URL').Storage::disk('local')->url($value);
    }

    /**
     * @var array
     */
    protected $fillable=['name','description','price','image','size','color','qty','barcode'];
    protected $hidden = [
    'created_at', 'deleted_at','updated_at',
    ];
}
