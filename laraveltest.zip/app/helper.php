<?php

    if (!function_exists('error')) {
        /**
         * @param string $message
         * @param string $data
         * @param int    $responseCode
         *
         * @return \Illuminate\Http\JsonResponse
         */
        function error($message = "", $data = "", $responseCode = 400)
        {

            $result['message'] = $message;
            $result['status'] = 'false';
            if (is_array($data))
                $result['result'] = $data;
            return showResult($result, $responseCode);

        }
    }


    if (!function_exists('myDateNow')) {
        /**
         * @param string $format
         *
         * @return bool|string
         */
        function myDateNow($format = 'Y-m-d H:i:s')
        {
            return date($format);
        }
    }


    if (!function_exists('success')) {

        /**
         * @param string $message
         * @param string $data
         * @param int    $responseCode
         *
         * @return \Illuminate\Http\JsonResponse
         */
        function success($message = "", $data = "", $responseCode = 200)
        {
            $result['message'] = $message;
            $result['status'] = 'true';
            if (is_array($data))
                $result['result'] = array_remove_null($data);

            return showResult($result, $responseCode);
        }
    }
    if (!function_exists('array_remove_null')) {
        function array_remove_null($array)
        {
            if ($array != null) {
                foreach ($array as $key => $value) {
                    //print_r($value);
                    if (is_null($value))
                        $array[$key] = "";
                    if (is_array($value))
                        $array[$key] = array_remove_null($value);
                }
            }
            return $array;
        }
    }
    if (!function_exists('showResult')) {

        /**
         * @param $result
         * @param $responseCode
         *
         * @return \Illuminate\Http\JsonResponse
         */
        function showResult($result, $responseCode)
        {
            http_response_code($responseCode);
            header('Content-Type: application/json');
            echo json_encode($result, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
            exit(0);
            /*Log::info('requests', [
                'request'       => request()->all(),
                'response'      => print_r($result, true),
                'response_code' => $responseCode
            ]);*/

        }
        if (!function_exists('uploadFile')) {
    function uploadFile($request, $file_key, $storage_path)
    {
        if ($request->hasFile($file_key)) {
            if ($request->file($file_key)->isValid()) {
                $image = $request->file($file_key);
                $fileName = time() . "." . $image->getClientOriginalExtension();
                Storage::disk('public')->put($storage_path.$fileName,File::get($image));
                return$storage_path.$fileName;
            } else {
                return null;
            }
        }
        return null;
    }
}

    }

