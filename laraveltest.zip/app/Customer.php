<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\City;

class Customer extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    use SoftDeletes;
    protected $table = 'customers';

    /**
     * @var array
     */
    protected $fillable=['name','contact_no','city_id'];
    protected $hidden = [
    'created_at', 'deleted_at','updated_at',
    ];
    public function city(){
        return $this->hasOne('App\City','id','city_id');
    }
     public function getCityIdAttribute($value)
    {
        $data = (object) [];
        if(!empty($value)){
            return City::find($value);
        }else {
            return json_encode($data);
        }
    }
}
