<?php
namespace App\Helpers;

class SettingsHelper{

    protected $vars;

    public function all(){
        return $this->vars;
    }

    public function get($key, $default = null){

        if (is_array($this->vars) && array_key_exists($key, $this->vars)) {
            return $this->vars[$key];
        }

        return $default;
    }

    public function put($key, $value){
        return $this->vars[$key] =$value;
    }

}
?>