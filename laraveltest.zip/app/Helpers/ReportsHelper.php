<?php
namespace App\Helpers;
use App\Http\Controllers\api\ProductController;


class ReportsHelper{

    protected $vars;
    protected $reportData;

    public function all(){
        return $this->vars;
    }

    public function get(){

       
        /*  
            Report Type  Session Exists  
            report_type

        */
        if(session()->exists('report_type') != '' ){
            // Make  Object Of Controller 
             $controller = 'App\\Http\\Controllers\\api\\'.ucfirst(session('report_type')).'Controller';
            $ObjectData =  new $controller ;
            return  $ObjectData->get();
            
        }
        
        //return $default;
    }

    public function put($key, $value){
        return $this->vars[$key] =$value;
    }

}
?>