<?php


namespace App\Http\Controllers\Voyager;
use TCG\Voyager\Http\Controllers\VoyagerBaseController as BaseVoyagerController;



use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Events\BreadDataAdded;
use TCG\Voyager\Events\BreadDataDeleted;
use TCG\Voyager\Events\BreadDataRestored;
use TCG\Voyager\Events\BreadDataUpdated;
use TCG\Voyager\Events\BreadImagesDeleted;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\Traits\BreadRelationshipParser;
use VideoThumbnail;

class PostsController extends BaseVoyagerController
{
    use BreadRelationshipParser;

 
    public function generatebarcode(Request $request)
    {
        $idOf  =  $request->route('id');      
        $productDetail = '';
        $productID = '';

        if($idOf !=   '' &&  $idOf > 0 ){
            $productDetail  = DB::table('products')->where('id',$idOf)->first();
            $productID =  $idOf;
        }
        $ProductsList  =   DB::table('products')->where('deleted_at',NULL)->get();
        if (view()->exists("voyager::generatebarcode")) {
            $view = "voyager::generatebarcode";
        }
        
        return Voyager::view($view,compact('ProductsList','productDetail','productID'));
    }
    public function generatebarcodesave(Request $request)
    {
        $dataProductBarcode  =  $request->all();
       // dd($dataProductBarcode);

        if(isset($dataProductBarcode['barcode']) && $dataProductBarcode['barcode']  == ''){
             return redirect()
                ->route('voyager.generatebarcode')
                ->with([
                        'message'    =>'Please enter barcode.',
                        'alert-type' => 'error',
                    ]);
        }

        if(isset($dataProductBarcode['product_id']) && $dataProductBarcode['product_id']  == ''){
           return redirect()
                ->route('voyager.product')
                ->with([
                        'message'    =>'Please select at least one product.',
                        'alert-type' => 'error',
                    ]);
        }
        
        // Generate BArcode and save in Directory  
        $pathOf = '/var/www/html/shopping-app/storage/app/public/products/barcodes/';
        $imageName  = 'barcode-'.$dataProductBarcode["product_id"].'.png';
        $generator = new \Picqer\Barcode\BarcodeGeneratorPNG();  
        file_put_contents($pathOf.$imageName, $generator->getBarcode($dataProductBarcode["barcode"], $generator::TYPE_CODE_93, 3, 50));
         
         $dataProductBarcodeUpdate['barcode'] = $dataProductBarcode['barcode'];
         $dataProductBarcodeUpdate['size'] = $dataProductBarcode['size'];
         $dataProductBarcodeUpdate['price'] = $dataProductBarcode['price'];
         $dataProductBarcodeUpdate['image'] = $imageName;
         $companyData  =   DB::table('products')->where('id',$dataProductBarcode['product_id'])->update($dataProductBarcodeUpdate);

        return redirect()
                ->route('voyager.generatebarcodeset',$dataProductBarcode['product_id'])
                ->with([
                        'message'    =>'Barcode has been Generated successfully.',
                        'alert-type' => 'success',
                    ]);
        //return Voyager::view('voyager::companyprofile',compact('companyData'));
    }
     
}
