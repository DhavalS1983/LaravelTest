<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Product;
use Illuminate\Support\Facades\Storage;
class ProductController extends Controller
{   
    public function __construct(Product $product)
    {
        $this->model = $product;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $product = $this->model->orderBy('id','desc')->get();
        if(count($product)>0)
            return success('Product Listed Successfully.',$product->toArray());
        else
            return error('Product not found',null ,404);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductRequest $request)
    {
        $getProduct = $request->all();
        $this->model->fill($getProduct);
        if ($request->hasFile('image')) {
            $this->model->image = uploadFile($request, 'image', 'products/');
        }
        if($this->model->save())
            return success('Product added Successfully',$this->model->fresh()->toArray());
        else
            return error('Something is wrong in product add',null ,404);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $proData =  $request->all();        
        $getProduct = $this->model->find($proData['product_id']);        
        if(!$getProduct){
             return error('Product not found',null ,404);
        }
        $getProduct->fill($request->all());
         if ($request->hasFile('image')) {
            $getProduct->image = uploadFile($request, 'image', 'products/');
        }
        if($getProduct->save())
            return success('Product updated Successfully',array($getProduct->fresh()->toArray()));
        else
            return error('Something is wrong in product add',null ,404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $getProduct = $this->model->find($request->get('product_id'));
        if(!$getProduct){
             return error('Product not found',null ,404);
        }
        if($getProduct->delete($request->get('product_id'))){
            return success('Product deletd Successfully',200);
        }else{
           return error('Something is wrong in product delete',null ,404);
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function searchBarcode(Request $request)
    {
        $getProduct = Product::where('barcode',$request->get('code'))->first();
        //dd($getProduct);
        if(!$getProduct){
             return error('Product not found',null ,404);
        }
        else{
            return success('Product updated Successfully',array($getProduct ));
        }
    }
}
