<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Product;
use Illuminate\Support\Facades\Storage;
class ProductreportController extends Controller
{   
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function get()
    {
        $this->model =  new Product();
         $product = $this->model->orderBy('id','desc')->get();
        if(count($product)>0)
            return $product->toArray();
        else
            return error('Product not found',null ,404);
    }
    public function getReport(){
        // Via the global helper...
            session(['report_type' => 'productreport']);
           // app('reports')->put('test', 'test2');
            $data = app('reports')->get();
            return success('Data',$data);
    }
}
