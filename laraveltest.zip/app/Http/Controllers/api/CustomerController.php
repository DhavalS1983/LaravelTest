<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\CustomerRequest;
use App\Customer;
use App\City;

class CustomerController extends Controller
{
    public function __construct(Customer $customer)
    {
        $this->model = $customer;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer = $this->model->orderBy('id','desc')->get();
        if(count($customer)>0)
            return success('Customer Listed Successfully.',$customer->toArray());
        else
            return error('Customer not found',null ,404);

    }
    public function listCity(){
        $list = City::get();
        if(count($list)>0)
            return success('City Listed Successfully.',$list->toArray());
        else
            return error('City not found',null ,404);
    }
    public function add_customer(Request $request)
    {
        $getCustomer = $request->all();
        //dd($getCustomer);
        //Check unique  on saave  
        if(isset($getCustomer['customer_id']) &&  $getCustomer['customer_id'] > 0){
            $coustomerPhoneCheck = Customer::where('id', '=', $getCustomer['customer_id'])->first();
             $getCustomer = $this->model->find($request->get('customer_id'));
                if(!$getCustomer){
                     return error('Customer not found',null ,404);
                }
                $getCustomer->fill($request->all());
                if($getCustomer->save())
                    return success('Customer updated Successfully',array($getCustomer->fresh()->toArray()));
                else
                    return error('Something is wrong in customer update',null ,404);
        }else{
            $coustomerPhoneCheck = Customer::where('contact_no', '=', $getCustomer['contact_no'])->first();
            if(empty($coustomerPhoneCheck)){
                    // Inseert 
                    $this->model->fill($getCustomer);
                    if($this->model->save())
                        return success('Customer added Successfully',array($this->model->toArray()));
                    else
                        return error('Something is wrong in customer add',null ,404);
            }else{
                return error('Customer already exists with this number.',null ,404);   
            }
        }
        

        
    }
    public function store(CustomerRequest $request)
    {
        $getCustomer = $request->all();
        //Check unique  on saave  
       if(isset($getCustomer['id']) &&  $getCustomer['id'] > 0){
            $coustomerPhoneCheck = Customer::where('contact_no', '=', $getCustomer['contact_no'])
            ->where('id', '!=', $getCustomer['id'])->first();
            $getCustomer = $this->model->find($getCustomer['id']);
            if(!$getCustomer){
                     return error('Customer not found',null ,404);
                }
            if(empty($coustomerPhoneCheck)){
 
                $getCustomer->fill($request->all());
                if($getCustomer->save())
                 return success('Customer updated Successfully',array($getCustomer->fresh()->toArray()));
                else
                    return error('Something is wrong in customer update',null ,404);
            }else{
                return error('Customer already exists with this number.',null ,404);
            }
       }else{

            $coustomerPhoneCheck = Customer::where('contact_no', '=', $getCustomer['contact_no'])->first();
            if(empty($coustomerPhoneCheck)){
                // Inseert 
                $this->model->fill($getCustomer);
                if($this->model->save())
                    return success('Customer added Successfully',array($this->model->toArray()));
                else
                    return error('Something is wrong in customer add',null ,404);
            }else{
                return error('Customer already exists with this number.',null ,404);   
            }
       }
        
        

        
    }
    public function update(Request $request)
    {
        $getCustomer = $this->model->find($request->get('customer_id'));
        if(!$getCustomer){
             return error('Customer not found',null ,404);
        }
        $getCustomer->fill($request->all());
        if($getCustomer->save())
            return success('Customer updated Successfully',array($getCustomer->fresh()->toArray()));
        else
            return error('Something is wrong in customer update',null ,404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $getCustomer = $this->model->find($request->get('customer_id'));
        if(!$getCustomer){
             return error('Customer not found',null ,404);
        }
        if($getCustomer->delete($request->get('customer_id'))){
            return success('Customer deletd Successfully',200);
        }else{
           return error('Something is wrong in customer delete',null ,404);
        }
    }
}
