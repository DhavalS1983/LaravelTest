<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    // public function authorize()
    // {
    //     return false;
    // }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch (\Request::route()->getName()) {
            case "product.store":
                $rules = [
                    'name'      => 'required',
                    'price'     => 'required',             
                ];
                break;
            case "product.update":
                $rules = [
                    'name'      => 'required',
                    'price'     => 'required',             
                ];
                break;               
                $rules = [];
            }
            return $rules;
    }
   protected function failedValidation(Validator $validator) {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }
}
