<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
class CustomerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    // public function authorize()
    // {
    //     return false;
    // }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
       // print_r(\Request::route()->getName());exit;
        switch (\Request::route()->getName()) {
            case "customer.store":
                $rules = [
                    'name'      => 'required',
                    'contact_no'     => 'required',             
                ];
                break;
            case "update_customer":
                $rules = [
                    'name'      => 'required',
                    'contact_no'     => 'required',
                    'customer_id'     => 'required',             
                ];
                break;         
                $rules = [];
            }
            return $rules;
    }
   protected function failedValidation(Validator $validator) {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }
}
