<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Helpers\ReportsHelper;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {

        include (app_path("helper.php"));
        $this->app->singleton('reports', function ($app) {
            return new \App\Helpers\ReportsHelper;
        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
