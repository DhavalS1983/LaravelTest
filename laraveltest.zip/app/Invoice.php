<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Invoice extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
    */
    protected $table = 'invoices';

    /**
     * @var array
     */
    protected $fillable=['customer_name','product_name','customer_id','product_id','quntity','total_amount','date'];
    protected $hidden = [
    'created_at', 'deleted_at','updated_at',
    ];
    public function setDateAttribute()
    {
        return date('Y-m-d H:i:s');
    }
}
