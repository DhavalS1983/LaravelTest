<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::group(['prefix' => 'v1', 'namespace' => 'api'], function () {
	Route::post('add_customer','CustomerController@add_customer');
	Route::resource('customer','CustomerController');
	Route::resource('product','ProductController');
	Route::resource('invoice','InvoiceController');
	Route::get('city','CustomerController@listCity');
	Route::post('update_customer','CustomerController@update');

	Route::post('searchBarcode','ProductController@searchBarcode');
	Route::post('get_report','ProductreportController@getReport');
	Route::post('update_product','ProductController@update');
	Route::post('delete_customer','CustomerController@destroy');
	Route::post('delete_product','ProductController@destroy');
	Route::post('invoice/addInvoice','InvoiceController@addInvoice');
	Route::post('invoice/invoiceDetail','InvoiceController@invoiceDetail');
});